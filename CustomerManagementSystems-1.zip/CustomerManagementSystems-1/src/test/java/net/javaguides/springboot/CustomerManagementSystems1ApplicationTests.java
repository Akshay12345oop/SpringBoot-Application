package net.javaguides.springboot;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;



import net.javaguides.springboot.entity.Customers;
import net.javaguides.springboot.repository.CustomerRepository;

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
class CustomerManagementSystems1ApplicationTests {
	@Autowired
    CustomerRepository CMSrepo;

	@Test
	@Order(1)
    public void testsave() {
        
        Customers c = new Customers();
        c.setId(1L);
        c.setFirstName("Akshith");
        c.setLastName("Macharla");
        c.setNickName("Tinku");
        c.setSEX("Male");
        c.setAge(23);
        c.setQualification("B.E");
        c.setAddress("Hyderabad");
        c.setCommunicationAddress("Mhbd");
        c.setNotes("Customer Management System");
        CMSrepo.save(c);
        assertNotNull(CMSrepo.findById(1L).get());
        
    }
	
	//gettingAllData
	 @Test
	    @Order(2)
	    public void testgetAllData() {
	        List<Customers> list=CMSrepo.findAll();
	        assertThat(list).size().isGreaterThan(0);
	    }
	 //getting_data_by_id
	    @Test
	    @Order(3)
	    public void testgetSingleData() {
	        Customers customers=CMSrepo.findById(1L).get();
	        assertEquals(1,customers.getId());
	    }
	    
	    //update_lastname
	    @Test
	    @Order(4)
	    public void testUpdate() {
	        Customers c=CMSrepo.findById(1L).get();
	        c.setLastName("Hi");
	        CMSrepo.save(c);
	        assertNotEquals("Macharla",CMSrepo.findById(1L).get().getLastName());
	    }
	    //delete_by_id
	    @Test
	    @Order(5)
	    public void testDelete() {
	    	CMSrepo.deleteById(1L);
	        assertThat(CMSrepo.existsById(1L)).isFalse();
	    }


}
