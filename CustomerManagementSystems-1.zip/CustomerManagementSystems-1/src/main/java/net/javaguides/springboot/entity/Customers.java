package net.javaguides.springboot.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="Customers_TBL")
public class Customers {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;

	@NotEmpty(message="First name not entered")
	private String FirstName;
	
	@NotEmpty(message="Last name not entered")
	private String LastName;
		
	@NotEmpty(message="NickName not entered")
	private String NickName;
	
	@NotEmpty(message="SEX not entered")
	private String SEX;
	
	@NotNull(message="Age not entered")
	@Min(value = 15)
	@Max(value = 100)
	private int Age;
	
	@NotEmpty(message="Qualification not entered")
	private String Qualification;
	
	@NotEmpty(message="Address not entered")
	private String Address;
	
	@NotEmpty(message="Communiocation address not entered")
	private String CommunicationAddress;
	
	
	@NotEmpty(message="Notes not entered")
	private String Notes;
	
	
	@Override
	public String toString() {
		return "TravelModel [id=" + id + ", FirstName=" + FirstName + ", LastName=" + LastName + ", NickName="
				+ NickName + ", SEX=" + SEX + ", Age=" + Age
				+ ", Qualification=" + Qualification +" Address=" + Address
				+ ", CommunicationAddress=" + CommunicationAddress + ", Notes=" + Notes
				+ "]";
	}


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getFirstName() {
		return FirstName;
	}


	public void setFirstName(String firstName) {
		FirstName = firstName;
	}


	public String getLastName() {
		return LastName;
	}


	public void setLastName(String lastName) {
		LastName = lastName;
	}


	public String getNickName() {
		return NickName;
	}


	public void setNickName(String nickName) {
		NickName = nickName;
	}


	public String getSEX() {
		return SEX;
	}


	public void setSEX(String sEX) {
		SEX = sEX;
	}


	public int getAge() {
		return Age;
	}


	public void setAge(int age) {
		Age = age;
	}


	public String getQualification() {
		return Qualification;
	}


	public void setQualification(String qualification) {
		Qualification = qualification;
	}


	public String getAddress() {
		return Address;
	}


	public void setAddress(String address) {
		Address = address;
	}


	public String getCommunicationAddress() {
		return CommunicationAddress;
	}


	public void setCommunicationAddress(String communicationAddress) {
		CommunicationAddress = communicationAddress;
	}


	public String getNotes() {
		return Notes;
	}


	public void setNotes(String notes) {
		Notes = notes;
	}
	
	

}
