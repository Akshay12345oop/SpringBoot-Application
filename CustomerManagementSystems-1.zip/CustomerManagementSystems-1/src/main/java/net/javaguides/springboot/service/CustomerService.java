package net.javaguides.springboot.service;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import net.javaguides.springboot.entity.Customers;
import net.javaguides.springboot.repository.CustomerRepository;




@Service
public class CustomerService {
	
	@Autowired
	CustomerRepository customerRepository;
	
	public ResponseEntity<Customers> save(Customers customers) {
		try {
			return new ResponseEntity<>(customerRepository.save(customers), HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	public ResponseEntity<List<Customers>> getAllData() {
		try {
			List<Customers> list = customerRepository.findAll();
			if (list.isEmpty() || list.size() == 0) {
				return new ResponseEntity<List<Customers>>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<List<Customers>>(list,HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	public ResponseEntity<Customers> getSingleData( Long id) {
		Optional<Customers> customers = customerRepository.findById(id);
		
		if (customers.isPresent()) {
			return new ResponseEntity<Customers>(customers.get(), HttpStatus.OK );
			
		}
		   return new ResponseEntity<Customers>(HttpStatus.NOT_FOUND);	
		}
	
	public ResponseEntity<Customers> updateCustomers( Customers customers ) {
		try {
			return new ResponseEntity<Customers>(customerRepository.save(customers), HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	public ResponseEntity<HttpStatus> deleteCustomers( Long id) {
		try {
			Optional<Customers> customers = customerRepository.findById(id);
			if (customers.isPresent()) {
				customerRepository.delete(customers.get());
			}
			return new ResponseEntity<HttpStatus>(HttpStatus.ACCEPTED);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
